var name="Aadarsh";
console.log(name);
name="Jaipal";
console.log(name);
name="Grisha";
console.log(name);