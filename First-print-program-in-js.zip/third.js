var name="Aadarsh";
var age=22;

console.log(name,age);
console.log(typeof(name),typeof(age));