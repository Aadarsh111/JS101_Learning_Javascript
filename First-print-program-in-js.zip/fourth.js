var name="Chris";
    school="DAV Centenary Public School";
    grade=10;
    section="A";
    roll_no=111;
    english=75;
    science=89;
    maths=94;
const max_marks=100;

console.log(`
***********█▀█ █▀▀ █▀ █░█ █░░ ▀█▀
           █▀▄ ██▄ ▄█ █▄█ █▄▄ ░█░**********`)
console.log(" ");
console.log("");
console.log("");
console.log("Name = ",name);
console.log("Grade = ",grade);
console.log("Section = ",section);
console.log("Roll no. = ",roll_no);
console.log("School = ",school);
console.log(" ");
console.log(" ");

console.log("***************************************")

console.log(" ");
console.log(" ");
console.log("Subject          Max Marks          Marks");
console.log(" ")
console.log("English          ",max_marks,"              ",english);
console.log("Science          ",max_marks,"              ",science);
console.log("Maths            ",max_marks,"              ",maths);