let a="       Masai School";
b="A Transformation in Education";
console.log(a);
console.log(b);