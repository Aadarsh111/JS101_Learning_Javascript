let a="goku";
b="hi";

console.log(a+b);
console.log(typeof(a+b));
