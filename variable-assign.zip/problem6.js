let a="goku";
let b=5;

console.log(a+b);
console.log(typeof(a+b));