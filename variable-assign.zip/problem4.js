let a=64;
b=0.5;

console.log(a**b);