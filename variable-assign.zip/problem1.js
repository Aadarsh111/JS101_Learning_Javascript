var a=1;
const b=2;

console.log(typeof(a));

